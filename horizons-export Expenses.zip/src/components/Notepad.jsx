import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import { Plus, FileText } from "lucide-react";
import NoteForm from "@/components/NoteForm";
import NoteList from "@/components/NoteList";
import NoteView from "@/components/NoteView";

const Notepad = ({ notes, setNotes }) => {
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [isEditingNote, setIsEditingNote] = useState(null);
  const [viewingNote, setViewingNote] = useState(null);
  const { toast } = useToast();

  const handleAddNote = (newNote) => {
    if (isEditingNote) {
      setNotes((prevNotes) =>
        prevNotes.map((note) => (note.id === newNote.id ? newNote : note))
      );
      setIsEditingNote(null);
      
      if (viewingNote && viewingNote.id === newNote.id) {
        setViewingNote(newNote);
      }
    } else {
      setNotes((prevNotes) => [...prevNotes, newNote]);
      setIsAddingNote(false);
    }
  };

  const handleEditNote = (note) => {
    setIsEditingNote(note);
    setViewingNote(null);
  };

  const handleDeleteNote = (id) => {
    const noteToDelete = notes.find(note => note.id === id);
    setNotes((prevNotes) => prevNotes.filter((note) => note.id !== id));
    
    if (viewingNote && viewingNote.id === id) {
      setViewingNote(null);
    }
    
    toast({
      title: "Note deleted",
      description: `${noteToDelete.title} has been deleted.`,
    });
  };

  const handleViewNote = (note) => {
    setViewingNote(note);
  };

  return (
    <div className="space-y-6">
      {!viewingNote ? (
        <>
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <h2 className="text-3xl font-bold gradient-heading">Notepad</h2>
              <p className="text-muted-foreground">
                Create and manage your notes offline
              </p>
            </div>
            <Button onClick={() => setIsAddingNote(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Note
            </Button>
          </div>

          <NoteList
            notes={notes}
            onDeleteNote={handleDeleteNote}
            onEditNote={handleEditNote}
            onViewNote={handleViewNote}
          />
        </>
      ) : (
        <NoteView
          note={viewingNote}
          onBack={() => setViewingNote(null)}
          onEdit={handleEditNote}
          onDelete={handleDeleteNote}
        />
      )}

      <Dialog open={isAddingNote} onOpenChange={setIsAddingNote}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Note</DialogTitle>
          </DialogHeader>
          <NoteForm
            onAddNote={handleAddNote}
            onCancel={() => setIsAddingNote(false)}
          />
        </DialogContent>
      </Dialog>

      <Dialog
        open={!!isEditingNote}
        onOpenChange={(open) => !open && setIsEditingNote(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Note</DialogTitle>
          </DialogHeader>
          {isEditingNote && (
            <NoteForm
              initialNote={isEditingNote}
              onAddNote={handleAddNote}
              onCancel={() => setIsEditingNote(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Notepad;