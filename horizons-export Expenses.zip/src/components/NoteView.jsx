
import React from "react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { ArrowLeft, Edit, Trash2, Clock } from "lucide-react";

const NoteView = ({ note, onBack, onEdit, onDelete }) => {
  if (!note) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-4"
    >
      <div className="flex items-center justify-between">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onBack}
          className="flex items-center"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Notes
        </Button>
        
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onEdit(note)}
            className="flex items-center"
          >
            <Edit className="h-4 w-4 mr-2" />
            Edit
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onDelete(note.id)}
            className="flex items-center text-destructive"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Delete
          </Button>
        </div>
      </div>
      
      <div className="space-y-4 mt-6">
        <h1 className="text-2xl font-bold">{note.title}</h1>
        
        <div className="flex items-center text-sm text-muted-foreground">
          <Clock className="h-4 w-4 mr-1" />
          Last updated: {format(new Date(note.updatedAt), "MMM d, yyyy 'at' h:mm a")}
        </div>
        
        <div className="border-t border-border pt-4 mt-4">
          <div className="note-content whitespace-pre-wrap">
            {note.content || <span className="text-muted-foreground italic">No content</span>}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default NoteView;
