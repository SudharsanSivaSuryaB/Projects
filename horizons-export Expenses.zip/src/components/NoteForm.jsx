
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import { v4 as uuidv4 } from "uuid";

const NoteForm = ({ onAddNote, onCancel, initialNote = null }) => {
  const [title, setTitle] = useState(initialNote?.title || "");
  const [content, setContent] = useState(initialNote?.content || "");
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast({
        title: "Missing title",
        description: "Please enter a title for your note",
        variant: "destructive",
      });
      return;
    }

    const newNote = {
      id: initialNote?.id || uuidv4(),
      title: title.trim(),
      content,
      createdAt: initialNote?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onAddNote(newNote);
    toast({
      title: initialNote ? "Note updated" : "Note created",
      description: `${title} has been ${initialNote ? "updated" : "created"}.`,
    });

    // Reset form if not editing
    if (!initialNote) {
      setTitle("");
      setContent("");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-4"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="title">Note Title</Label>
          <Input
            id="title"
            placeholder="Enter note title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="content">Content</Label>
          <Textarea
            id="content"
            placeholder="Write your note here..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[200px]"
          />
        </div>
        
        <div className="flex justify-end space-x-2 pt-4">
          <Button variant="outline" type="button" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit">
            {initialNote ? "Update Note" : "Add Note"}
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

export default NoteForm;
