
import React, { useMemo } from "react";
import { motion } from "framer-motion";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PieChart, 
  Calendar 
} from "lucide-react";

const ExpenseStats = ({ expenses }) => {
  const stats = useMemo(() => {
    if (!expenses.length) {
      return {
        totalExpenses: 0,
        averageExpense: 0,
        highestExpense: { amount: 0, title: "None" },
        recentExpenses: 0,
        categorySummary: [],
      };
    }

    // Total expenses
    const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    
    // Average expense
    const averageExpense = totalExpenses / expenses.length;
    
    // Highest expense
    const highestExpense = expenses.reduce(
      (highest, expense) => 
        expense.amount > highest.amount ? expense : highest,
      { amount: 0 }
    );
    
    // Recent expenses (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const recentExpenses = expenses
      .filter(expense => new Date(expense.date) >= thirtyDaysAgo)
      .reduce((sum, expense) => sum + expense.amount, 0);
    
    // Category summary
    const categoryMap = {};
    expenses.forEach(expense => {
      if (!categoryMap[expense.category]) {
        categoryMap[expense.category] = 0;
      }
      categoryMap[expense.category] += expense.amount;
    });
    
    const categorySummary = Object.entries(categoryMap)
      .map(([category, amount]) => ({
        category,
        amount,
        percentage: (amount / totalExpenses) * 100,
      }))
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 5); // Top 5 categories
    
    return {
      totalExpenses,
      averageExpense,
      highestExpense,
      recentExpenses,
      categorySummary,
    };
  }, [expenses]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <motion.div 
          className="stats-card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-medium text-muted-foreground">Total Expenses</h3>
            <DollarSign className="h-4 w-4 text-primary" />
          </div>
          <p className="text-2xl font-bold mt-2">${stats.totalExpenses.toFixed(2)}</p>
        </motion.div>
        
        <motion.div 
          className="stats-card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-medium text-muted-foreground">Last 30 Days</h3>
            <Calendar className="h-4 w-4 text-primary" />
          </div>
          <p className="text-2xl font-bold mt-2">${stats.recentExpenses.toFixed(2)}</p>
        </motion.div>
        
        <motion.div 
          className="stats-card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-medium text-muted-foreground">Average Expense</h3>
            <TrendingUp className="h-4 w-4 text-primary" />
          </div>
          <p className="text-2xl font-bold mt-2">${stats.averageExpense.toFixed(2)}</p>
        </motion.div>
        
        <motion.div 
          className="stats-card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-medium text-muted-foreground">Highest Expense</h3>
            <TrendingDown className="h-4 w-4 text-primary" />
          </div>
          <p className="text-2xl font-bold mt-2">${stats.highestExpense.amount.toFixed(2)}</p>
          <p className="text-xs text-muted-foreground mt-1">{stats.highestExpense.title}</p>
        </motion.div>
      </div>
      
      {stats.categorySummary.length > 0 && (
        <motion.div 
          className="stats-card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-medium">Top Categories</h3>
            <PieChart className="h-4 w-4 text-primary" />
          </div>
          
          <div className="space-y-4">
            {stats.categorySummary.map((category) => (
              <div key={category.category}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm">{category.category}</span>
                  <span className="text-sm font-medium">${category.amount.toFixed(2)}</span>
                </div>
                <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-primary"
                    initial={{ width: 0 }}
                    animate={{ width: `${category.percentage}%` }}
                    transition={{ duration: 1, delay: 0.6 }}
                  />
                </div>
                <span className="text-xs text-muted-foreground">
                  {category.percentage.toFixed(1)}%
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default ExpenseStats;
