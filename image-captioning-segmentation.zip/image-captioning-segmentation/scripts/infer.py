import argparse, yaml, torch
from PIL import Image
from src.serving.blip_captioner import load_blip_pipeline, generate_caption
from src.serving.deeplab_segmenter import load_deeplab, predict_mask
from src.serving.overlay import overlay

def main(image_path, out_path, cfg_path):
    cfg = yaml.safe_load(open(cfg_path))
    device = cfg.get('device', 'cuda' if torch.cuda.is_available() else 'cpu')

    img = Image.open(image_path).convert('RGB')

    # Caption
    if cfg.get('use_pretrained_captioner', True):
        processor, blip = load_blip_pipeline(device)
        caption = generate_caption(img, processor, blip, device=device)
    else:
        # TODO: load baseline LSTM checkpoint from cfg['caption_checkpoint']
        caption = "(baseline LSTM captioner not loaded; set use_pretrained_captioner=true for BLIP)"
    print("Caption:", caption)

    # Segmentation
    if cfg.get('use_pretrained_segmenter', True):
        deeplab, preprocess = load_deeplab(device)
        mask = predict_mask(deeplab, preprocess, img, device=device)
    else:
        # TODO: load UNet checkpoint from cfg['segment_checkpoint']
        raise RuntimeError("Set use_pretrained_segmenter=true to use DeepLabV3 or implement UNet checkpoint load.")
    vis = overlay(img, mask)
    vis.save(out_path)
    print("Saved overlay to:", out_path)

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--image', required=True)
    ap.add_argument('--out', default='out.png')
    ap.add_argument('--config', default='configs/inference.yaml')
    args = ap.parse_args()
    main(args.image, args.out, args.config)
