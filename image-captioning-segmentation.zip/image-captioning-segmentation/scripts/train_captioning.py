import argparse, os, random
import yaml, nltk, torch, torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import transforms as T
from src.captioning.dataset import CocoCaptionDataset
from src.captioning.model import CaptioningModel
from src.captioning.utils import Vocab, pad_sequences

def set_seed(s=42):
    random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)

def build_vocab(ann_file, min_freq=2):
    import json, collections
    with open(ann_file, 'r', encoding='utf-8') as f:
        ann = json.load(f)
    all_tokens = []
    for a in ann['annotations']:
        toks = nltk.word_tokenize(a['caption'].lower())
        all_tokens.extend(toks)
    return Vocab(all_tokens, min_freq=min_freq)

def collate(batch, pad_idx=0):
    imgs, seqs = zip(*batch)
    return torch.stack(imgs), pad_sequences(seqs, pad_idx=pad_idx)

def main(cfg_path):
    cfg = yaml.safe_load(open(cfg_path))
    set_seed(cfg.get('seed', 42))
    device = cfg.get('device', 'cuda' if torch.cuda.is_available() else 'cpu')

    vocab = build_vocab(cfg['ann_file'])
    transform = T.Compose([T.Resize((256,256)), T.ToTensor(),
                           T.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])])
    ds = CocoCaptionDataset(cfg['data_root'], cfg['ann_file'], cfg['img_folder'], vocab, transform=transform)
    dl = DataLoader(ds, batch_size=cfg['batch_size'], shuffle=True, num_workers=cfg['num_workers'], collate_fn=lambda b: collate(b, pad_idx=vocab.stoi['<pad>']))

    model = CaptioningModel(vocab_size=len(vocab.itos), embed_dim=cfg['embed_dim'], hidden_dim=cfg['hidden_dim']).to(device)
    criterion = nn.CrossEntropyLoss(ignore_index=vocab.stoi['<pad>'])
    optim = torch.optim.AdamW(model.parameters(), lr=cfg['lr'])

    os.makedirs(cfg['checkpoint_dir'], exist_ok=True)
    for epoch in range(cfg['epochs']):
        model.train()
        total = 0.0
        for i, (imgs, caps) in enumerate(dl):
            imgs, caps = imgs.to(device), caps.to(device)
            logits = model(imgs, caps)
            loss = criterion(logits.reshape(-1, logits.size(-1)), caps.reshape(-1))
            optim.zero_grad(); loss.backward(); optim.step()
            total += loss.item()
            if (i+1) % 50 == 0:
                print(f"Epoch {epoch+1} Step {i+1}/{len(dl)} Loss {total/(i+1):.4f}")
        torch.save({'model': model.state_dict(), 'vocab': vocab.itos}, os.path.join(cfg['checkpoint_dir'], f'epoch{epoch+1}.pt'))
    print("Training finished!")

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='configs/training_captioning.yaml')
    args = ap.parse_args()
    main(args.config)
