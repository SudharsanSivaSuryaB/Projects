import argparse, os, random
import yaml, torch, torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import transforms as T
from src.segmentation.dataset import VocSegmentation
from src.segmentation.model_unet import UNet

def set_seed(s=42):
    random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)

def main(cfg_path):
    cfg = yaml.safe_load(open(cfg_path))
    set_seed(cfg.get('seed', 42))
    device = cfg.get('device', 'cuda' if torch.cuda.is_available() else 'cpu')

    transform = T.Compose([T.Resize((256,256)), T.ToTensor()])
    ds = VocSegmentation(cfg['data_root'], transform=transform)
    dl = DataLoader(ds, batch_size=cfg['batch_size'], shuffle=True, num_workers=cfg['num_workers'])

    model = UNet(num_classes=cfg['num_classes']).to(device)
    criterion = nn.CrossEntropyLoss()
    optim = torch.optim.AdamW(model.parameters(), lr=cfg['lr'])

    os.makedirs(cfg['checkpoint_dir'], exist_ok=True)
    for epoch in range(cfg['epochs']):
        model.train(); total=0.0
        for i, (imgs, masks) in enumerate(dl):
            imgs, masks = imgs.to(device), masks.to(device)
            logits = model(imgs)
            loss = criterion(logits, masks)
            optim.zero_grad(); loss.backward(); optim.step()
            total += loss.item()
            if (i+1) % 20 == 0:
                print(f"Epoch {epoch+1} Step {i+1}/{len(dl)} Loss {total/(i+1):.4f}")
        torch.save({'model': model.state_dict()}, os.path.join(cfg['checkpoint_dir'], f'epoch{epoch+1}.pt'))
    print("Training finished!")

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='configs/training_segmentation.yaml')
    args = ap.parse_args()
    main(args.config)
