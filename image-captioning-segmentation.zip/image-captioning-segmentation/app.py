import streamlit as st
from PIL import Image
import torch

st.set_page_config(page_title="Image Captioning + Segmentation", layout="centered")

st.title("🖼️ Image Captioning + Segmentation")
st.write("Upload an image to get a generated caption and a semantic segmentation overlay.")

uploaded = st.file_uploader("Upload image", type=["jpg","jpeg","png","bmp"])

device = 'cuda' if torch.cuda.is_available() else 'cpu'

if uploaded is not None:
    img = Image.open(uploaded).convert('RGB')
    st.image(img, caption="Input", use_column_width=True)

    # Lazy import to show friendly errors if deps missing
    try:
        from src.serving.blip_captioner import load_blip_pipeline, generate_caption
        processor, blip = load_blip_pipeline(device)
        caption = generate_caption(img, processor, blip, device=device)
        st.success(f"**Caption:** {caption}")
    except Exception as e:
        st.error(f"Captioning dependency missing or failed: {e}")
        st.info("Try: pip install transformers")

    try:
        from src.serving.deeplab_segmenter import load_deeplab, predict_mask
        from src.serving.overlay import overlay
        deeplab, preprocess = load_deeplab(device)
        mask = predict_mask(deeplab, preprocess, img, device=device)
        vis = overlay(img, mask)
        st.image(vis, caption="Segmentation overlay", use_column_width=True)
    except Exception as e:
        st.error(f"Segmentation dependency missing or failed: {e}")
        st.info("Try: pip install torch torchvision")
else:
    st.info("Drop an image above to begin.")
