import numpy as np
import cv2

def colorize_mask(mask: np.ndarray):
    # Expect mask as HxW integer classes
    n_classes = int(mask.max()) + 1 if mask.size else 1
    rng = np.random.default_rng(0)
    palette = rng.integers(0, 255, size=(max(n_classes, 21), 3), dtype=np.uint8)
    color = palette[mask % len(palette)]
    return color

def overlay_mask_on_image(img_bgr: np.ndarray, mask: np.ndarray, alpha: float = 0.5):
    color = colorize_mask(mask)
    color = cv2.resize(color, (img_bgr.shape[1], img_bgr.shape[0]), interpolation=cv2.INTER_NEAREST)
    return cv2.addWeighted(img_bgr, 1 - alpha, color, alpha, 0)
