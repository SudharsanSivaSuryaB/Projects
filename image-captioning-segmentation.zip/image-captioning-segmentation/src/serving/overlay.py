import numpy as np
import cv2
from PIL import Image
from src.common.viz import overlay_mask_on_image

def overlay(image: Image.Image, mask):
    img_bgr = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    vis = overlay_mask_on_image(img_bgr, mask, alpha=0.5)
    return Image.fromarray(cv2.cvtColor(vis, cv2.COLOR_BGR2RGB))
