import torch
from typing import Optional
from PIL import Image

def load_blip_pipeline(device='cpu'):
    try:
        from transformers import BlipProcessor, BlipForConditionalGeneration
        import torch
    except Exception as e:
        raise RuntimeError("Missing dependency: transformers (pip install transformers)") from e

    model_name = "Salesforce/blip-image-captioning-base"
    processor = BlipProcessor.from_pretrained(model_name)
    model = BlipForConditionalGeneration.from_pretrained(model_name).to(device)
    model.eval()
    return processor, model


def generate_caption(image: Image.Image, processor, model, device='cpu', max_length=30):
    inputs = processor(images=image, return_tensors="pt").to(device)
    out = model.generate(**inputs, max_length=max_length)
    return processor.decode(out[0], skip_special_tokens=True)
