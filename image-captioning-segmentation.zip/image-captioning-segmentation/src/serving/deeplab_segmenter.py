import torch
import torchvision
import numpy as np
from PIL import Image

def load_deeplab(device='cpu'):
    model = torchvision.models.segmentation.deeplabv3_resnet50(weights=torchvision.models.segmentation.DeepLabV3_ResNet50_Weights.DEFAULT)
    model.to(device).eval()
    preprocess = torchvision.models.segmentation.DeepLabV3_ResNet50_Weights.DEFAULT.transforms()
    return model, preprocess

@torch.inference_mode()
def predict_mask(model, preprocess, image: Image.Image, device='cpu'):
    inp = preprocess(image).unsqueeze(0).to(device)
    out = model(inp)['out'].softmax(dim=1).argmax(dim=1)[0].cpu().numpy().astype('uint8')
    return out
