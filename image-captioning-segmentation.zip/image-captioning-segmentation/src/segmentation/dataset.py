import os
from PIL import Image
import numpy as np
from torch.utils.data import Dataset
from torchvision import transforms as T

class VocSegmentation(Dataset):
    def __init__(self, data_root, img_folder='JPEGImages', mask_folder='SegmentationClass', transform=None):
        self.img_dir = os.path.join(data_root, img_folder)
        self.mask_dir = os.path.join(data_root, mask_folder)
        self.ids = [f.split('.')[0] for f in os.listdir(self.img_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
        self.transform = transform or T.Compose([T.Resize((256,256)), T.ToTensor()])

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, idx):
        id_ = self.ids[idx]
        img = Image.open(os.path.join(self.img_dir, id_ + '.jpg')).convert('RGB')
        mask_path = os.path.join(self.mask_dir, id_ + '.png')
        mask = Image.open(mask_path)
        img = self.transform(img)
        mask = mask.resize((img.shape[2], img.shape[1]), resample=Image.NEAREST)
        mask = np.array(mask, dtype=np.int64)
        return img, mask
