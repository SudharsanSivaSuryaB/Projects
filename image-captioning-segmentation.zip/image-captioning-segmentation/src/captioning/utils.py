import collections
import torch

class Vocab:
    def __init__(self, tokens, min_freq=1):
        counter = collections.Counter(tokens)
        self.itos = ['<pad>', '<bos>', '<eos>', '<unk>']
        for tok, freq in counter.items():
            if freq >= min_freq and tok not in self.itos:
                self.itos.append(tok)
        self.stoi = {s:i for i,s in enumerate(self.itos)}

    def numericalize(self, tokens):
        return [self.stoi.get(t, self.stoi['<unk>']) for t in tokens]

def pad_sequences(seqs, pad_idx=0):
    maxlen = max(len(s) for s in seqs)
    out = torch.full((len(seqs), maxlen), pad_idx, dtype=torch.long)
    for i, s in enumerate(seqs):
        out[i, :len(s)] = torch.tensor(s, dtype=torch.long)
    return out
