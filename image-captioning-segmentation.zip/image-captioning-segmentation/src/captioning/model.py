import torch
import torch.nn as nn
import torchvision.models as models

class EncoderCNN(nn.Module):
    def __init__(self, embed_dim=256):
        super().__init__()
        resnet = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
        modules = list(resnet.children())[:-1]
        self.backbone = nn.Sequential(*modules)
        self.fc = nn.Linear(resnet.fc.in_features, embed_dim)
        self.bn = nn.BatchNorm1d(embed_dim, momentum=0.01)

    def forward(self, images):
        with torch.no_grad():
            feats = self.backbone(images).squeeze()  # (B, 2048)
        feats = self.bn(self.fc(feats))
        return feats

class DecoderLSTM(nn.Module):
    def __init__(self, vocab_size, embed_dim=256, hidden_dim=512, num_layers=1):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_dim, vocab_size)

    def forward(self, features, captions):
        # features: (B, E) -> (B, 1, E)
        embeddings = torch.cat([features.unsqueeze(1), self.embed(captions[:, :-1])], dim=1)
        h, _ = self.lstm(embeddings)
        out = self.fc(h)
        return out

class CaptioningModel(nn.Module):
    def __init__(self, vocab_size, embed_dim=256, hidden_dim=512):
        super().__init__()
        self.encoder = EncoderCNN(embed_dim=embed_dim)
        self.decoder = DecoderLSTM(vocab_size, embed_dim=embed_dim, hidden_dim=hidden_dim)

    def forward(self, images, captions):
        feats = self.encoder(images)
        logits = self.decoder(feats, captions)
        return logits
