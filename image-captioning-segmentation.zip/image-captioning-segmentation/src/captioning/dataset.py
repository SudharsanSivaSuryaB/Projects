import json, os
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms as T
import nltk
from collections import defaultdict

class CocoCaptionDataset(Dataset):
    def __init__(self, data_root, ann_file, img_folder, vocab, transform=None):
        self.data_root = data_root
        self.ann_file = ann_file
        self.img_dir = os.path.join(data_root, img_folder)
        self.transform = transform or T.Compose([T.Resize((256,256)), T.ToTensor()])
        with open(ann_file, 'r', encoding='utf-8') as f:
            ann = json.load(f)
        # Build image id -> file, and id -> captions
        self.id_to_file = {img['id']: img['file_name'] for img in ann['images']}
        caps = defaultdict(list)
        for c in ann['annotations']:
            caps[c['image_id']].append(c['caption'])
        self.samples = [(img_id, self.id_to_file[img_id], caps[img_id]) for img_id in caps.keys() if img_id in self.id_to_file]
        self.vocab = vocab

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_id, file_name, captions = self.samples[idx]
        img = Image.open(os.path.join(self.img_dir, file_name)).convert('RGB')
        img = self.transform(img)
        # take first caption
        caption = captions[0]
        tokens = nltk.word_tokenize(caption.lower())
        tokens = ['<bos>'] + tokens + ['<eos>']
        ids = [self.vocab.stoi.get(tok, self.vocab.stoi['<unk>']) for tok in tokens]
        return img, ids
