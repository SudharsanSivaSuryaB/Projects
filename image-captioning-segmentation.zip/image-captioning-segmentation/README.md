# Image Captioning & Segmentation — End‑to‑End Project

This project delivers a complete, **production-ready** scaffold for the dual task of **Image Captioning** and **Image Segmentation**, aligned with the uploaded brief. It includes:

- Training loops for **captioning** (CNN+LSTM baseline) and **segmentation** (U‑Net baseline).
- **Pretrained inference path**: BLIP captioning (via 🤗 `transformers`) and DeepLabV3 (via `torchvision`) for strong zero-shot results.
- A **Streamlit** demo app (`app.py`) to upload an image, auto‑caption it, and generate a semantic segmentation mask overlay.
- Clean modular code under `src/`, configs in `configs/`, and ready-to-run scripts in `scripts/`.
- Works on CPU/GPU. For best results, use GPU with CUDA.

> **Datasets**: For training, you can plug in **MS COCO** (captioning) and **Pascal VOC**/**COCO** (segmentation). Sample dataset loaders are provided. For quick demo, run the Streamlit app with pretrained models—no training needed.

---

## Quickstart (Demo, no training needed)

```bash
# 1) Create env (recommended) and install requirements
pip install -r requirements.txt

# 2) (Optional) NLTK tokenizer data for BLEU evaluation
python -m nltk.downloader punkt

# 3) Launch the Streamlit demo
streamlit run app.py
```
Then open the local URL Streamlit prints (e.g., http://localhost:8501). Upload an image and enjoy caption + segmentation.

---

## Training (Optional)

### Captioning (CNN+LSTM baseline)
```bash
python scripts/train_captioning.py   --data_root /path/to/coco   --ann_file /path/to/captions_train2017.json   --epochs 10 --batch_size 64 --num_workers 4
```

### Segmentation (U‑Net baseline)
```bash
python scripts/train_segmentation.py   --data_root /path/to/VOC2012   --epochs 30 --batch_size 8 --num_workers 4
```

Checkpoints are saved to `checkpoints/` by default (configurable).

---

## Inference with Pretrained Models

- **Captioning**: Uses BLIP (Salesforce/blip-image-captioning-base) by default. You can also switch to the baseline LSTM if you trained it (see `configs/inference.yaml`).  
- **Segmentation**: Uses `torchvision.models.segmentation.deeplabv3_resnet50(pretrained=True)`.

```bash
python scripts/infer.py --image /path/to/image.jpg --out out.png
```

---

## Project Structure

```
image-captioning-segmentation/
├─ app.py
├─ requirements.txt
├─ README.md
├─ configs/
│  ├─ training_captioning.yaml
│  ├─ training_segmentation.yaml
│  └─ inference.yaml
├─ scripts/
│  ├─ train_captioning.py
│  ├─ train_segmentation.py
│  └─ infer.py
├─ src/
│  ├─ __init__.py
│  ├─ captioning/
│  │  ├─ __init__.py
│  │  ├─ dataset.py
│  │  ├─ model.py
│  │  └─ utils.py
│  ├─ segmentation/
│  │  ├─ __init__.py
│  │  ├─ dataset.py
│  │  ├─ model_unet.py
│  │  └─ utils.py
│  ├─ common/
│  │  ├─ __init__.py
│  │  ├─ transforms.py
│  │  └─ viz.py
│  └─ serving/
│     ├─ blip_captioner.py
│     ├─ deeplab_segmenter.py
│     └─ overlay.py
├─ checkpoints/            # created at runtime
└─ samples/
   └─ demo.jpg             # put your own sample here
```

---

## Notes

- Training loops are concise but complete. Feel free to expand augmentations and schedulers.
- Streamlit app auto‑falls back gracefully if a dependency is missing (it will tell you what to `pip install`).

Happy hacking! 🚀
