import { useState, useCallback } from 'react';
import { Calculator, CalculationHistory, CalculationType, generateId, saveHistoryToStorage, loadHistoryFromStorage, clearHistoryFromStorage } from '@/lib/calculator';
import { useToast } from '@/hooks/use-toast';

export function useCalculator() {
  const [calculator] = useState(() => new Calculator());
  const [expression, setExpression] = useState('');
  const [result, setResult] = useState('0');
  const [history, setHistory] = useState<CalculationHistory[]>(() => loadHistoryFromStorage());
  const { toast } = useToast();

  const updateDisplay = useCallback((expr?: string, res?: string) => {
    setExpression(expr ?? calculator.getExpression());
    setResult(res ?? calculator.getResult());
  }, [calculator]);

  const addToHistory = useCallback((expr: string, res: string, type: CalculationType) => {
    const newEntry: CalculationHistory = {
      id: generateId(),
      expression: expr,
      result: res,
      type,
      timestamp: new Date().toLocaleTimeString()
    };
    
    const newHistory = [newEntry, ...history];
    setHistory(newHistory);
    saveHistoryToStorage(newHistory);
  }, [history]);

  const addNumber = useCallback((value: string) => {
    const expr = calculator.addToExpression(value);
    updateDisplay(expr);
  }, [calculator, updateDisplay]);

  const addOperator = useCallback((operator: string) => {
    const expr = calculator.addToExpression(` ${operator} `);
    updateDisplay(expr);
  }, [calculator, updateDisplay]);

  const addDecimal = useCallback(() => {
    const currentExpr = calculator.getExpression();
    if (!currentExpr.includes('.')) {
      const expr = calculator.addToExpression('.');
      updateDisplay(expr);
    }
  }, [calculator, updateDisplay]);

  const clear = useCallback(() => {
    calculator.clear();
    updateDisplay();
  }, [calculator, updateDisplay]);

  const deleteLast = useCallback(() => {
    const expr = calculator.deleteLast();
    updateDisplay(expr);
  }, [calculator, updateDisplay]);

  const calculate = useCallback(() => {
    try {
      const expr = calculator.getExpression();
      if (!expr) return;
      
      const res = calculator.calculate();
      updateDisplay(expr, res);
      addToHistory(expr, res, 'manual');
    } catch (error) {
      toast({
        title: "Calculation Error",
        description: error instanceof Error ? error.message : "Invalid calculation",
        variant: "destructive",
      });
    }
  }, [calculator, updateDisplay, addToHistory, toast]);

  const calculateAdvanced = useCallback((operation: 'sqrt' | 'power' | 'percent') => {
    try {
      const res = calculator.calculateAdvanced(operation);
      const expr = calculator.getExpression();
      updateDisplay(expr, res);
      addToHistory(expr, res, 'advanced');
    } catch (error) {
      toast({
        title: "Calculation Error",
        description: error instanceof Error ? error.message : "Invalid operation",
        variant: "destructive",
      });
    }
  }, [calculator, updateDisplay, addToHistory, toast]);

  const processVoiceCalculation = useCallback((input: string) => {
    try {
      const res = calculator.processVoiceCalculation(input);
      const expr = calculator.getExpression();
      updateDisplay(expr, res);
      addToHistory(expr, res, 'voice');
      
      // Show success toast
      toast({
        title: "Voice Calculation Complete",
        description: `Result: ${res}`,
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Voice Calculation Error",
        description: error instanceof Error ? error.message : "Could not process voice input",
        variant: "destructive",
      });
    }
  }, [calculator, updateDisplay, addToHistory, toast]);

  const loadFromHistory = useCallback((item: CalculationHistory) => {
    calculator.setExpression(item.expression);
    calculator.setResult(item.result);
    updateDisplay(item.expression, item.result);
  }, [calculator, updateDisplay]);

  const clearHistory = useCallback(() => {
    setHistory([]);
    clearHistoryFromStorage();
  }, []);

  return {
    expression,
    result,
    history,
    addNumber,
    addOperator,
    addDecimal,
    clear,
    deleteLast,
    calculate,
    calculateAdvanced,
    processVoiceCalculation,
    loadFromHistory,
    clearHistory
  };
}
