import { useTheme as useThemeOriginal } from "@/components/theme-provider";

export const useTheme = useThemeOriginal;
