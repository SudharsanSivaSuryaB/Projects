import { useState, useCallback, useRef, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

interface VoiceRecognitionHook {
  isListening: boolean;
  transcript: string;
  isSupported: boolean;
  countdown: number;
  startListening: () => void;
  stopListening: () => void;
  resetTranscript: () => void;
}

export function useVoiceRecognition(
  onCalculate?: (input: string) => void
): VoiceRecognitionHook {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isSupported, setIsSupported] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const recognition = useRef<any>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const countdownRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      
      if (SpeechRecognition) {
        setIsSupported(true);
        recognition.current = new SpeechRecognition();
        
        const rec = recognition.current;
        rec.continuous = true;
        rec.interimResults = true;
        rec.lang = 'en-US';

        rec.onstart = () => {
          setIsListening(true);
        };

        rec.onresult = (event: any) => {
          let interimTranscript = '';
          let finalTranscript = '';

          for (let i = event.resultIndex; i < event.results.length; i++) {
            const result = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalTranscript += result;
            } else {
              interimTranscript += result;
            }
          }

          const fullTranscript = finalTranscript + interimTranscript;
          setTranscript(fullTranscript);

          // Check for "calculate" keyword
          const lowerTranscript = fullTranscript.toLowerCase();
          
          console.log('Voice transcript:', lowerTranscript);
          
          // Clear any existing timeout
          if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
          }
          if (countdownRef.current) {
            clearTimeout(countdownRef.current);
          }
          
          // Look for "calculate" keyword
          if (lowerTranscript.includes('calculate')) {
            const expression = lowerTranscript.replace(/calculate/g, '').trim();
            console.log('Found calculate expression:', expression);
            
            // Start countdown
            setCountdown(3);
            let currentCount = 3;
            
            const countdownTimer = () => {
              currentCount--;
              setCountdown(currentCount);
              
              if (currentCount > 0) {
                countdownRef.current = setTimeout(countdownTimer, 1000);
              } else {
                // Process calculation after countdown
                if (expression && onCalculate) {
                  console.log('Processing calculation after 3 seconds:', expression);
                  onCalculate(expression);
                  setTranscript('');
                  setCountdown(0);
                  rec.stop();
                }
              }
            };
            
            countdownRef.current = setTimeout(countdownTimer, 1000);
          } else {
            setCountdown(0);
          }
        };

        rec.onerror = (event: any) => {
          console.error('Speech recognition error:', event.error);
          toast({
            title: "Voice Recognition Error",
            description: `Error: ${event.error}`,
            variant: "destructive",
          });
          setIsListening(false);
        };

        rec.onend = () => {
          setIsListening(false);
          // Clear timeouts when recognition ends
          if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
            timeoutRef.current = null;
          }
          if (countdownRef.current) {
            clearTimeout(countdownRef.current);
            countdownRef.current = null;
          }
          setCountdown(0);
        };
      } else {
        setIsSupported(false);
      }
    }

    return () => {
      if (recognition.current) {
        recognition.current.stop();
      }
    };
  }, [onCalculate, toast]);

  const startListening = useCallback(() => {
    if (recognition.current && !isListening) {
      setTranscript('');
      try {
        recognition.current.start();
      } catch (error) {
        console.error('Failed to start voice recognition:', error);
        toast({
          title: "Voice Recognition Error",
          description: "Failed to start voice recognition",
          variant: "destructive",
        });
      }
    }
  }, [isListening, toast]);

  const stopListening = useCallback(() => {
    if (recognition.current && isListening) {
      recognition.current.stop();
    }
    // Clear timeouts when manually stopping
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    if (countdownRef.current) {
      clearTimeout(countdownRef.current);
      countdownRef.current = null;
    }
    setCountdown(0);
  }, [isListening]);

  const resetTranscript = useCallback(() => {
    setTranscript('');
  }, []);

  return {
    isListening,
    transcript,
    isSupported,
    countdown,
    startListening,
    stopListening,
    resetTranscript
  };
}

// Extend the global Window interface to include speech recognition
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}
