import { Delete, History, Calculator as CalcIcon, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { VoiceControls } from "./voice-controls";

interface ButtonGridProps {
  onNumber: (value: string) => void;
  onOperator: (operator: string) => void;
  onDecimal: () => void;
  onClear: () => void;
  onDelete: () => void;
  onCalculate: () => void;
  onAdvanced: (operation: 'sqrt' | 'power' | 'percent') => void;
  onHistoryToggle: () => void;
  onVoiceToggle: () => void;
  isVoiceListening: boolean;
  isVoiceSupported: boolean;
}

export function ButtonGrid({
  onNumber,
  onOperator,
  onDecimal,
  onClear,
  onDelete,
  onCalculate,
  onAdvanced,
  onHistoryToggle,
  onVoiceToggle,
  isVoiceListening,
  isVoiceSupported
}: ButtonGridProps) {
  return (
    <div className="flex-1 p-4">
      <div className="grid grid-cols-4 gap-3 h-full">
        {/* Row 1: Clear, History, Voice, Delete */}
        <Button onClick={onClear} className="calc-clear">
          <Trash2 className="text-lg" />
        </Button>
        <Button onClick={onHistoryToggle} className="calc-history">
          <History className="text-lg" />
        </Button>
        <VoiceControls
          isListening={isVoiceListening}
          isSupported={isVoiceSupported}
          onToggle={onVoiceToggle}
        />
        <Button onClick={onDelete} className="calc-delete">
          <Delete className="text-lg" />
        </Button>

        {/* Row 2: Advanced Functions */}
        <Button onClick={() => onAdvanced('sqrt')} className="calc-function text-sm">
          √
        </Button>
        <Button onClick={() => onAdvanced('power')} className="calc-function text-sm">
          x²
        </Button>
        <Button onClick={() => onAdvanced('percent')} className="calc-function">
          %
        </Button>
        <Button onClick={() => onOperator('÷')} className="calc-operator text-xl">
          ÷
        </Button>

        {/* Row 3: Numbers 7, 8, 9, × */}
        <Button onClick={() => onNumber('7')} className="calc-number text-xl">
          7
        </Button>
        <Button onClick={() => onNumber('8')} className="calc-number text-xl">
          8
        </Button>
        <Button onClick={() => onNumber('9')} className="calc-number text-xl">
          9
        </Button>
        <Button onClick={() => onOperator('×')} className="calc-operator text-xl">
          ×
        </Button>

        {/* Row 4: Numbers 4, 5, 6, - */}
        <Button onClick={() => onNumber('4')} className="calc-number text-xl">
          4
        </Button>
        <Button onClick={() => onNumber('5')} className="calc-number text-xl">
          5
        </Button>
        <Button onClick={() => onNumber('6')} className="calc-number text-xl">
          6
        </Button>
        <Button onClick={() => onOperator('−')} className="calc-operator text-xl">
          −
        </Button>

        {/* Row 5: Numbers 1, 2, 3, + */}
        <Button onClick={() => onNumber('1')} className="calc-number text-xl">
          1
        </Button>
        <Button onClick={() => onNumber('2')} className="calc-number text-xl">
          2
        </Button>
        <Button onClick={() => onNumber('3')} className="calc-number text-xl">
          3
        </Button>
        <Button onClick={() => onOperator('+')} className="calc-operator text-xl">
          +
        </Button>

        {/* Row 6: 0, ., = */}
        <Button onClick={() => onNumber('0')} className="col-span-2 calc-number text-xl">
          0
        </Button>
        <Button onClick={onDecimal} className="calc-number text-xl">
          .
        </Button>
        <Button onClick={onCalculate} className="calc-equals text-xl">
          =
        </Button>
      </div>
    </div>
  );
}
