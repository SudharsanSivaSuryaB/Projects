import { Mic, MicOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface VoiceControlsProps {
  isListening: boolean;
  isSupported: boolean;
  onToggle: () => void;
  className?: string;
}

export function VoiceControls({ 
  isListening, 
  isSupported, 
  onToggle, 
  className 
}: VoiceControlsProps) {
  if (!isSupported) {
    return null;
  }

  return (
    <Button
      onClick={onToggle}
      className={cn(
        "calc-voice",
        {
          "calc-voice recording": isListening,
        },
        className
      )}
    >
      {isListening ? (
        <MicOff className="text-lg" />
      ) : (
        <Mic className="text-lg" />
      )}
    </Button>
  );
}
