import { cn } from "@/lib/utils";

interface DisplayProps {
  expression: string;
  result: string;
  voiceTranscript?: string;
  isVoiceActive?: boolean;
  countdown?: number;
  className?: string;
}

export function Display({ 
  expression, 
  result, 
  voiceTranscript, 
  isVoiceActive = false,
  countdown = 0,
  className 
}: DisplayProps) {
  return (
    <div className={cn("calc-display", className)}>
      {/* Voice Input Indicator */}
      {isVoiceActive && (
        <div className="mb-4 flex flex-col items-center justify-center space-y-2 text-red-500 animate-slide-down">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-red-500 rounded-full" style={{animation: 'voice-listening 1.5s infinite'}}></div>
            <span className="text-sm font-medium">Voice Recognition Active</span>
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400 text-center">
            {countdown > 0 ? `Processing in ${countdown} seconds...` : 'Say: "calculate two plus three" (waits 3 seconds)'}
          </div>
        </div>
      )}

      {/* Expression Display */}
      <div className="text-right mb-2">
        <div className="text-gray-600 dark:text-gray-400 text-lg font-light min-h-[24px]">
          {expression}
        </div>
      </div>

      {/* Result Display */}
      <div className="text-right">
        <div className="text-4xl font-semibold text-gray-900 dark:text-white min-h-[48px] break-all">
          {result}
        </div>
      </div>

      {/* Voice Input Display */}
      {isVoiceActive && voiceTranscript && (
        <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border-l-4 border-blue-500 animate-slide-up">
          <div className="text-sm text-blue-700 dark:text-blue-300 font-medium">Voice Input:</div>
          <div className="text-gray-700 dark:text-gray-300 mt-1">{voiceTranscript}</div>
        </div>
      )}
    </div>
  );
}
