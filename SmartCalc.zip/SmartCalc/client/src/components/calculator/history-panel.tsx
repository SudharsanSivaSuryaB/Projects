import { useState } from "react";
import { X, Trash2, History as HistoryIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CalculationHistory } from "@/lib/calculator";
import { cn } from "@/lib/utils";

interface HistoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  history: CalculationHistory[];
  onClearHistory: () => void;
  onSelectItem: (item: CalculationHistory) => void;
}

export function HistoryPanel({
  isOpen,
  onClose,
  history,
  onClearHistory,
  onSelectItem
}: HistoryPanelProps) {
  const [isAnimating, setIsAnimating] = useState(false);

  const handleClose = () => {
    setIsAnimating(true);
    setTimeout(() => {
      onClose();
      setIsAnimating(false);
    }, 300);
  };

  const handleItemClick = (item: CalculationHistory) => {
    onSelectItem(item);
    handleClose();
  };

  if (!isOpen && !isAnimating) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 transition-opacity duration-300">
      <div
        className={cn(
          "absolute bottom-0 left-0 right-0 bg-white dark:bg-gray-800 rounded-t-3xl shadow-2xl transform transition-transform duration-300",
          {
            "translate-y-0": isOpen && !isAnimating,
            "translate-y-full": !isOpen || isAnimating,
          }
        )}
      >
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Calculation History
            </h2>
            <div className="flex space-x-2">
              <Button
                onClick={onClearHistory}
                variant="destructive"
                size="sm"
                className="px-4 py-2"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All
              </Button>
              <Button
                onClick={handleClose}
                variant="ghost"
                size="sm"
                className="p-2"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <ScrollArea className="max-h-96">
            {history.length === 0 ? (
              <div className="text-center py-12">
                <HistoryIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-400">No calculations yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {history.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => handleItemClick(item)}
                    className="p-4 bg-gray-50 dark:bg-gray-700 rounded-xl border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors duration-200 cursor-pointer"
                  >
                    <div className="flex justify-between items-center">
                      <div className="flex-1">
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          {item.expression}
                        </div>
                        <div className="text-lg font-semibold text-gray-900 dark:text-white">
                          = {item.result}
                        </div>
                        {item.type === 'voice' && (
                          <div className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                            Voice Input
                          </div>
                        )}
                        {item.type === 'advanced' && (
                          <div className="text-xs text-purple-600 dark:text-purple-400 mt-1">
                            Advanced Function
                          </div>
                        )}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        {item.timestamp}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}
