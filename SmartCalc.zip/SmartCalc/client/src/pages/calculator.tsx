import { useState, useCallback, useEffect } from "react";
import { Calculator as CalcIcon, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Display } from "@/components/calculator/display";
import { ButtonGrid } from "@/components/calculator/button-grid";
import { HistoryPanel } from "@/components/calculator/history-panel";
import { useCalculator } from "@/hooks/use-calculator";
import { useVoiceRecognition } from "@/hooks/use-voice-recognition";
import { useTheme } from "@/hooks/use-theme";

export default function Calculator() {
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  
  const {
    expression,
    result,
    history,
    addNumber,
    addOperator,
    addDecimal,
    clear,
    deleteLast,
    calculate,
    calculateAdvanced,
    processVoiceCalculation,
    loadFromHistory,
    clearHistory
  } = useCalculator();

  const {
    isListening,
    transcript,
    isSupported: isVoiceSupported,
    countdown,
    startListening,
    stopListening,
    resetTranscript
  } = useVoiceRecognition(processVoiceCalculation);

  const toggleTheme = useCallback(() => {
    setTheme(theme === "dark" ? "light" : "dark");
  }, [theme, setTheme]);

  const handleVoiceToggle = useCallback(() => {
    if (isListening) {
      stopListening();
      resetTranscript();
    } else {
      startListening();
    }
  }, [isListening, startListening, stopListening, resetTranscript]);

  const handleHistoryToggle = useCallback(() => {
    setIsHistoryOpen(!isHistoryOpen);
  }, [isHistoryOpen]);

  const handleHistorySelect = useCallback((item: any) => {
    loadFromHistory(item);
    setIsHistoryOpen(false);
  }, [loadFromHistory]);

  // Keyboard support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key;
      
      if (key >= '0' && key <= '9') {
        addNumber(key);
      } else if (key === '.') {
        addDecimal();
      } else if (key === '+') {
        addOperator('+');
      } else if (key === '-') {
        addOperator('−');
      } else if (key === '*') {
        addOperator('×');
      } else if (key === '/') {
        e.preventDefault();
        addOperator('÷');
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        calculate();
      } else if (key === 'Escape') {
        clear();
      } else if (key === 'Backspace') {
        deleteLast();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [addNumber, addOperator, addDecimal, clear, deleteLast, calculate]);

  return (
    <div className="min-h-screen flex flex-col max-w-sm mx-auto bg-white dark:bg-gray-800 shadow-2xl transition-colors duration-300">
      {/* Header */}
      <header className="flex justify-between items-center p-4 bg-blue-600 dark:bg-blue-800 text-white shadow-lg">
        <div className="flex items-center space-x-2">
          <CalcIcon className="text-xl" />
          <h1 className="text-lg font-semibold">Smart Calculator</h1>
        </div>
        <Button
          onClick={toggleTheme}
          variant="ghost"
          size="sm"
          className="p-2 rounded-full hover:bg-blue-700 dark:hover:bg-blue-700 text-white hover:text-white"
        >
          {theme === "dark" ? (
            <Sun className="text-lg" />
          ) : (
            <Moon className="text-lg" />
          )}
        </Button>
      </header>

      {/* Display */}
      <Display
        expression={expression}
        result={result}
        voiceTranscript={transcript}
        isVoiceActive={isListening}
        countdown={countdown}
      />

      {/* Button Grid */}
      <ButtonGrid
        onNumber={addNumber}
        onOperator={addOperator}
        onDecimal={addDecimal}
        onClear={clear}
        onDelete={deleteLast}
        onCalculate={calculate}
        onAdvanced={calculateAdvanced}
        onHistoryToggle={handleHistoryToggle}
        onVoiceToggle={handleVoiceToggle}
        isVoiceListening={isListening}
        isVoiceSupported={isVoiceSupported}
      />

      {/* History Panel */}
      <HistoryPanel
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onClearHistory={clearHistory}
        onSelectItem={handleHistorySelect}
      />
    </div>
  );
}
