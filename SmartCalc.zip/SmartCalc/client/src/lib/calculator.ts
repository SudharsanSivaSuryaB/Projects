export type CalculationType = 'manual' | 'voice' | 'advanced';

export interface CalculationHistory {
  id: string;
  expression: string;
  result: string;
  type: CalculationType;
  timestamp: string;
}

export class Calculator {
  private expression: string = '';
  private result: string = '0';

  constructor() {}

  addToExpression(value: string): string {
    this.expression += value;
    return this.expression;
  }

  setExpression(expression: string): string {
    this.expression = expression;
    return this.expression;
  }

  getExpression(): string {
    return this.expression;
  }

  setResult(result: string): string {
    this.result = result;
    return this.result;
  }

  getResult(): string {
    return this.result;
  }

  clear(): void {
    this.expression = '';
    this.result = '0';
  }

  deleteLast(): string {
    this.expression = this.expression.slice(0, -1);
    return this.expression;
  }

  calculate(): string {
    try {
      if (!this.expression.trim()) return this.result;

      // Replace display symbols with calculation symbols
      let expression = this.expression
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/−/g, '-')
        .trim();

      // Basic security check
      if (!/^[\d+\-*/.() ]+$/.test(expression)) {
        throw new Error('Invalid characters in expression');
      }

      // Use Function constructor for safer evaluation than eval
      const result = Function(`"use strict"; return (${expression})`)();
      
      if (!isFinite(result)) {
        throw new Error('Invalid calculation result');
      }

      this.result = result.toString();
      return this.result;
    } catch (error) {
      throw new Error('Invalid calculation');
    }
  }

  calculateAdvanced(operation: 'sqrt' | 'power' | 'percent'): string {
    try {
      const num = parseFloat(this.result);
      
      if (!isFinite(num)) {
        throw new Error('Invalid number');
      }

      let result: number;
      let expr: string;

      switch (operation) {
        case 'sqrt':
          if (num < 0) {
            throw new Error('Cannot calculate square root of negative number');
          }
          result = Math.sqrt(num);
          expr = `√${num}`;
          break;
        case 'power':
          result = Math.pow(num, 2);
          expr = `${num}²`;
          break;
        case 'percent':
          result = num / 100;
          expr = `${num}%`;
          break;
        default:
          throw new Error('Unknown operation');
      }

      this.expression = expr;
      this.result = result.toString();
      return this.result;
    } catch (error) {
      throw new Error(error instanceof Error ? error.message : 'Invalid operation');
    }
  }

  processVoiceCalculation(input: string): string {
    try {
      console.log('Processing voice input:', input);
      
      // Convert natural language to mathematical expressions
      let expression = input.toLowerCase()
        .replace(/\bplus\b/g, '+')
        .replace(/\bminus\b/g, '-')
        .replace(/\btimes\b/g, '*')
        .replace(/\bmultiplied by\b/g, '*')
        .replace(/\bdivided by\b/g, '/')
        .replace(/\bpercent of\b/g, '* 0.01 *')
        .replace(/\bsquare root of\b/g, 'Math.sqrt(')
        .replace(/\bsquared\b/g, '**2')
        .replace(/\band\b/g, '')
        .replace(/\bequals\b/g, '')
        .replace(/\bis\b/g, '')
        .replace(/\bwhat\b/g, '');

      console.log('Processed expression:', expression);

      // Try to extract mathematical parts using regex
      const numberPattern = /(\d+(?:\.\d+)?)/g;
      const operatorPattern = /(\+|\-|\*|\/)/g;
      
      const numbers = expression.match(numberPattern) || [];
      const operators = expression.match(operatorPattern) || [];
      
      console.log('Found numbers:', numbers);
      console.log('Found operators:', operators);

      // If we found numbers and operators, construct the expression
      if (numbers.length >= 2 && operators.length >= 1) {
        let mathExpression = numbers[0];
        for (let i = 0; i < operators.length && i + 1 < numbers.length; i++) {
          mathExpression += ` ${operators[i]} ${numbers[i + 1]}`;
        }
        
        console.log('Constructed math expression:', mathExpression);
        
        // Set expression for display
        this.expression = `Voice: "${input}"`;
        
        // Calculate result
        const result = Function(`"use strict"; return (${mathExpression})`)();
        
        if (!isFinite(result)) {
          throw new Error('Invalid calculation result');
        }

        this.result = result.toString();
        console.log('Calculation result:', this.result);
        return this.result;
      }
      
      // Fallback: try to find a simple math expression in the input
      const mathMatch = expression.match(/[\d+\-*/.() ]+/g);
      if (mathMatch && mathMatch[0].trim()) {
        const mathExpression = mathMatch[0].trim();
        console.log('Fallback math expression:', mathExpression);
        
        this.expression = `Voice: "${input}"`;
        const result = Function(`"use strict"; return (${mathExpression})`)();
        
        if (!isFinite(result)) {
          throw new Error('Invalid calculation result');
        }

        this.result = result.toString();
        return this.result;
      }
      
      throw new Error('No mathematical expression found');
    } catch (error) {
      console.error('Voice calculation error:', error);
      throw new Error('Could not process voice calculation');
    }
  }
}

export function saveHistoryToStorage(history: CalculationHistory[]): void {
  try {
    localStorage.setItem('calculatorHistory', JSON.stringify(history));
  } catch (error) {
    console.error('Failed to save history:', error);
  }
}

export function loadHistoryFromStorage(): CalculationHistory[] {
  try {
    const saved = localStorage.getItem('calculatorHistory');
    return saved ? JSON.parse(saved) : [];
  } catch (error) {
    console.error('Failed to load history:', error);
    return [];
  }
}

export function clearHistoryFromStorage(): void {
  try {
    localStorage.removeItem('calculatorHistory');
  } catch (error) {
    console.error('Failed to clear history:', error);
  }
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}
