import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCalculationSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get calculation history
  app.get("/api/calculations", async (req, res) => {
    try {
      const calculations = await storage.getCalculations();
      res.json(calculations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calculations" });
    }
  });

  // Save a calculation
  app.post("/api/calculations", async (req, res) => {
    try {
      const result = insertCalculationSchema.safeParse(req.body);
      if (!result.success) {
        res.status(400).json({ message: "Invalid calculation data" });
        return;
      }

      const calculation = await storage.createCalculation(result.data);
      res.json(calculation);
    } catch (error) {
      res.status(500).json({ message: "Failed to save calculation" });
    }
  });

  // Clear calculation history
  app.delete("/api/calculations", async (req, res) => {
    try {
      await storage.clearCalculations();
      res.json({ message: "Calculations cleared" });
    } catch (error) {
      res.status(500).json({ message: "Failed to clear calculations" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
