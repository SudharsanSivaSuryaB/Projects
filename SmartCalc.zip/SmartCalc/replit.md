# Calculator App

## Overview

A modern web-based calculator application built with React and Express.js. The app features a clean, responsive interface with support for basic arithmetic operations, advanced mathematical functions, voice input capabilities, and calculation history management. The application follows a full-stack architecture with a React frontend and Express.js backend, using PostgreSQL for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent, accessible UI components
- **State Management**: React hooks (`useState`, `useCallback`) combined with custom hooks for calculator logic and voice recognition
- **Routing**: Wouter for lightweight client-side routing
- **Data Fetching**: TanStack React Query for server state management and caching
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript for a robust REST API
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Session Management**: PostgreSQL-based session storage using connect-pg-simple
- **Middleware**: Custom logging middleware for API request tracking
- **Error Handling**: Centralized error handling with structured error responses

### Database Design
- **Users Table**: Basic user authentication schema with username/password
- **Calculations Table**: Stores calculation history with expression, result, type (manual/voice/advanced), and timestamp
- **Schema Management**: Drizzle migrations for version-controlled database changes

### Component Architecture
- **Calculator Core**: Modular calculator engine with separate classes for calculation logic
- **Voice Integration**: Web Speech API wrapper for voice-to-text calculation input
- **UI Components**: Reusable shadcn/ui components with custom calculator-specific styling
- **Theme System**: Dark/light mode support with CSS custom properties

### Key Features
- **Calculation Types**: Manual input, voice recognition, and advanced mathematical operations
- **History Management**: Persistent calculation history with local storage fallback
- **Responsive Design**: Mobile-first approach with touch-friendly button grid
- **Real-time Voice**: Live transcription with voice command processing
- **Error Handling**: Graceful error states with user-friendly messages

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: PostgreSQL database driver optimized for serverless environments
- **drizzle-orm**: Type-safe ORM for database operations and query building
- **@tanstack/react-query**: Server state management and data synchronization
- **express**: Node.js web framework for REST API development

### UI and Styling
- **@radix-ui/react-***: Accessible, unstyled UI primitives for complex components
- **tailwindcss**: Utility-first CSS framework for rapid UI development
- **class-variance-authority**: Type-safe variant API for component styling
- **lucide-react**: Modern icon library with React components

### Authentication and Session Management
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **drizzle-zod**: Integration between Drizzle ORM and Zod for schema validation

### Development Tools
- **vite**: Next-generation frontend build tool and development server
- **typescript**: Static type checking for enhanced developer experience
- **@replit/vite-plugin-***: Replit-specific development plugins for enhanced IDE integration

### Voice Recognition  
- **Web Speech API**: Browser-native speech recognition with enhanced pattern matching
- **Voice Commands**: "calculate [expression] end" pattern for calculation processing
- **Real-time Feedback**: Live transcript display with visual indicators
- **Error Handling**: Comprehensive voice recognition error management with user-friendly messages
- **Natural Language Processing**: Converts spoken words to mathematical expressions (plus, minus, times, etc.)

### Database and Migration
- **drizzle-kit**: Database migration and introspection tools
- **pg**: PostgreSQL client library for Node.js connections