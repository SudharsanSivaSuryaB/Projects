
import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Toaster } from "@/components/ui/toaster";
import { motion } from "framer-motion";
import { DollarSign, FileText } from "lucide-react";
import ExpensesTracker from "@/components/ExpensesTracker";
import Notepad from "@/components/Notepad";

const App = () => {
  const [activeTab, setActiveTab] = useState("expenses");

  return (
    <div className="min-h-screen app-background">
      <div className="container py-8 px-4 mx-auto max-w-5xl">
        <header className="mb-8 text-center">
          <motion.h1 
            className="text-4xl md:text-5xl font-bold gradient-heading mb-2"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Offline Tracker & Notes
          </motion.h1>
          <motion.p 
            className="text-muted-foreground"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Track expenses and take notes, all offline in your browser
          </motion.p>
        </header>

        <Tabs 
          defaultValue="expenses" 
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <div className="flex justify-center mb-6">
            <TabsList className="grid grid-cols-2 w-full max-w-md">
              <TabsTrigger value="expenses" className="flex items-center">
                <DollarSign className="h-4 w-4 mr-2" />
                Expenses
              </TabsTrigger>
              <TabsTrigger value="notes" className="flex items-center">
                <FileText className="h-4 w-4 mr-2" />
                Notes
              </TabsTrigger>
            </TabsList>
          </div>

          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <TabsContent value="expenses" className="mt-0">
              <ExpensesTracker />
            </TabsContent>
            
            <TabsContent value="notes" className="mt-0">
              <Notepad />
            </TabsContent>
          </motion.div>
        </Tabs>
      </div>
      <Toaster />
    </div>
  );
};

export default App;
