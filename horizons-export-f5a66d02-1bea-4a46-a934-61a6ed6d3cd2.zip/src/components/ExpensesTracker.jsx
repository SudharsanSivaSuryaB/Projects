
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import { Plus, BarChart2, List } from "lucide-react";
import ExpenseForm from "@/components/ExpenseForm";
import ExpenseList from "@/components/ExpenseList";
import ExpenseStats from "@/components/ExpenseStats";
import { getExpenses, saveExpenses } from "@/lib/storage";

const ExpensesTracker = () => {
  const [expenses, setExpenses] = useState([]);
  const [isAddingExpense, setIsAddingExpense] = useState(false);
  const [isEditingExpense, setIsEditingExpense] = useState(null);
  const [activeTab, setActiveTab] = useState("list");
  const { toast } = useToast();

  // Load expenses from localStorage on component mount
  useEffect(() => {
    const loadedExpenses = getExpenses();
    setExpenses(loadedExpenses);
  }, []);

  // Save expenses to localStorage whenever they change
  useEffect(() => {
    saveExpenses(expenses);
  }, [expenses]);

  const handleAddExpense = (newExpense) => {
    setExpenses([...expenses, newExpense]);
    setIsAddingExpense(false);
  };

  const handleEditExpense = (expense) => {
    setIsEditingExpense(expense);
  };

  const handleUpdateExpense = (updatedExpense) => {
    setExpenses(
      expenses.map((expense) =>
        expense.id === updatedExpense.id ? updatedExpense : expense
      )
    );
    setIsEditingExpense(null);
    toast({
      title: "Expense updated",
      description: `${updatedExpense.title} has been updated.`,
    });
  };

  const handleDeleteExpense = (id) => {
    const expenseToDelete = expenses.find(expense => expense.id === id);
    setExpenses(expenses.filter((expense) => expense.id !== id));
    toast({
      title: "Expense deleted",
      description: `${expenseToDelete.title} has been deleted.`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="space-y-1">
          <h2 className="text-3xl font-bold gradient-heading">Expenses Tracker</h2>
          <p className="text-muted-foreground">
            Track and manage your expenses offline
          </p>
        </div>
        <Button onClick={() => setIsAddingExpense(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Expense
        </Button>
      </div>

      <div className="flex space-x-2 border-b">
        <Button
          variant={activeTab === "list" ? "default" : "ghost"}
          className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
          data-state={activeTab === "list" ? "active" : "inactive"}
          onClick={() => setActiveTab("list")}
        >
          <List className="h-4 w-4 mr-2" />
          Expenses
        </Button>
        <Button
          variant={activeTab === "stats" ? "default" : "ghost"}
          className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
          data-state={activeTab === "stats" ? "active" : "inactive"}
          onClick={() => setActiveTab("stats")}
        >
          <BarChart2 className="h-4 w-4 mr-2" />
          Statistics
        </Button>
      </div>

      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
      >
        {activeTab === "list" ? (
          <ExpenseList
            expenses={expenses}
            onDeleteExpense={handleDeleteExpense}
            onEditExpense={handleEditExpense}
          />
        ) : (
          <ExpenseStats expenses={expenses} />
        )}
      </motion.div>

      {/* Add Expense Dialog */}
      <Dialog open={isAddingExpense} onOpenChange={setIsAddingExpense}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Expense</DialogTitle>
          </DialogHeader>
          <ExpenseForm
            onAddExpense={handleAddExpense}
            onCancel={() => setIsAddingExpense(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Expense Dialog */}
      <Dialog
        open={!!isEditingExpense}
        onOpenChange={(open) => !open && setIsEditingExpense(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Expense</DialogTitle>
          </DialogHeader>
          {isEditingExpense && (
            <ExpenseForm
              initialExpense={isEditingExpense}
              onAddExpense={handleUpdateExpense}
              onCancel={() => setIsEditingExpense(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ExpensesTracker;
