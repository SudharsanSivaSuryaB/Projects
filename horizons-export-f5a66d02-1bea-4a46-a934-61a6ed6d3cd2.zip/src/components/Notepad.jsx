
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import { Plus, FileText } from "lucide-react";
import NoteForm from "@/components/NoteForm";
import NoteList from "@/components/NoteList";
import NoteView from "@/components/NoteView";
import { getNotes, saveNotes } from "@/lib/storage";

const Notepad = () => {
  const [notes, setNotes] = useState([]);
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [isEditingNote, setIsEditingNote] = useState(null);
  const [viewingNote, setViewingNote] = useState(null);
  const { toast } = useToast();

  // Load notes from localStorage on component mount
  useEffect(() => {
    const loadedNotes = getNotes();
    setNotes(loadedNotes);
  }, []);

  // Save notes to localStorage whenever they change
  useEffect(() => {
    saveNotes(notes);
  }, [notes]);

  const handleAddNote = (newNote) => {
    if (isEditingNote) {
      // Update existing note
      setNotes(
        notes.map((note) => (note.id === newNote.id ? newNote : note))
      );
      setIsEditingNote(null);
      
      // Update viewing note if it's the one being edited
      if (viewingNote && viewingNote.id === newNote.id) {
        setViewingNote(newNote);
      }
    } else {
      // Add new note
      setNotes([...notes, newNote]);
      setIsAddingNote(false);
    }
  };

  const handleEditNote = (note) => {
    setIsEditingNote(note);
    setViewingNote(null);
  };

  const handleDeleteNote = (id) => {
    const noteToDelete = notes.find(note => note.id === id);
    setNotes(notes.filter((note) => note.id !== id));
    
    // Close view if the deleted note is being viewed
    if (viewingNote && viewingNote.id === id) {
      setViewingNote(null);
    }
    
    toast({
      title: "Note deleted",
      description: `${noteToDelete.title} has been deleted.`,
    });
  };

  const handleViewNote = (note) => {
    setViewingNote(note);
  };

  return (
    <div className="space-y-6">
      {!viewingNote ? (
        <>
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <h2 className="text-3xl font-bold gradient-heading">Notepad</h2>
              <p className="text-muted-foreground">
                Create and manage your notes offline
              </p>
            </div>
            <Button onClick={() => setIsAddingNote(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Note
            </Button>
          </div>

          <NoteList
            notes={notes}
            onDeleteNote={handleDeleteNote}
            onEditNote={handleEditNote}
            onViewNote={handleViewNote}
          />
        </>
      ) : (
        <NoteView
          note={viewingNote}
          onBack={() => setViewingNote(null)}
          onEdit={handleEditNote}
          onDelete={handleDeleteNote}
        />
      )}

      {/* Add Note Dialog */}
      <Dialog open={isAddingNote} onOpenChange={setIsAddingNote}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Note</DialogTitle>
          </DialogHeader>
          <NoteForm
            onAddNote={handleAddNote}
            onCancel={() => setIsAddingNote(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Note Dialog */}
      <Dialog
        open={!!isEditingNote}
        onOpenChange={(open) => !open && setIsEditingNote(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Note</DialogTitle>
          </DialogHeader>
          {isEditingNote && (
            <NoteForm
              initialNote={isEditingNote}
              onAddNote={handleAddNote}
              onCancel={() => setIsEditingNote(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Notepad;
