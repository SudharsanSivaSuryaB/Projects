import imaplib
import email
import json
import os

CONFIG_PATH = 'config.json'

def _load_config():
    if not os.path.exists(CONFIG_PATH):
        print('config.json not found. Copy config.example.json to config.json and fill credentials.')
        return None
    with open(CONFIG_PATH, 'r') as f:
        return json.load(f)

def read_emails_summary(limit=5):
    cfg = _load_config()
    if not cfg:
        return
    imap_server = cfg.get('imap_server')
    username = cfg.get('email')
    password = cfg.get('password')
    important_senders = cfg.get('important_senders', [])

    try:
        mail = imaplib.IMAP4_SSL(imap_server)
        mail.login(username, password)
        mail.select('inbox')
        typ, data = mail.search(None, 'ALL')
        ids = data[0].split()
        if not ids:
            print('No emails found.')
            return
        latest_ids = ids[-limit:]
        for num in reversed(latest_ids):
            typ, msg_data = mail.fetch(num, '(RFC822)')
            raw = msg_data[0][1]
            msg = email.message_from_bytes(raw)
            subj = msg['Subject'] or ''
            fr = msg['From'] or ''
            tag = ''
            if any(s.lower() in fr.lower() for s in important_senders):
                tag = 'IMPORTANT'
            elif 'meeting' in (subj or '').lower():
                tag = 'MEETING'
            else:
                tag = 'OTHER'
            print(f"[{tag}] From: {fr} | Subject: {subj}")
        mail.logout()
    except Exception as e:
        print('Failed to read emails:', e)
