# JerryAI v2 - main entrypoint with Porcupine wake word
import sys
from wakeword_listener import wait_for_wake_word
from voice_listener import recognize_from_queue
from command_handler import handle_command

def main():
    print("🤖 Jerry AI started. Say 'Jerry' to activate. Say 'exit jerry' to stop.")
    try:
        while True:
            wait_for_wake_word("jerry")
            print("🎤 Listening for command...")
            command = recognize_from_queue().lower().strip()
            if not command:
                continue
            print(f"🎤 Heard command: {command}")

            if command == "exit jerry" or ("exit" in command and "jerry" in command):
                print("👋 Exiting Jerry AI...")
                sys.exit(0)

            handle_command(command)

    except KeyboardInterrupt:
        print("\nInterrupted by user. Exiting.")

if __name__ == "__main__":
    main()
