# JerryAI v2 - Offline Personal Assistant

Features:
- Porcupine wake word ("Jerry") detection
- Offline Vosk STT for commands
- Open/close apps, type text
- Email fetch & filter
- Windows startup installer
- Ready for PyInstaller packaging

## Build .exe
```bash
pip install pyinstaller
pyinstaller --onefile main.py
```

## Auto Start on Boot
Run:
```bash
python install_startup.py
```

## Models
- Download Vosk model to `models/vosk-model-small-en-us-0.15`
- Porcupine comes with built-in keywords (use "jarvis", "computer", or train custom)
