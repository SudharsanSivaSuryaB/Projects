import os, sys

def add_to_startup(script_name="main.exe"):
    startup_dir = os.path.join(os.environ["APPDATA"], "Microsoft\Windows\Start Menu\Programs\Startup")
    script_path = os.path.join(os.getcwd(), script_name)
    shortcut_path = os.path.join(startup_dir, "JerryAI.lnk")

    try:
        import win32com.client
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(shortcut_path)
        shortcut.TargetPath = script_path
        shortcut.WorkingDirectory = os.getcwd()
        shortcut.save()
        print("✅ Jerry added to Windows Startup.")
    except Exception as e:
        print(f"❌ Failed to add startup shortcut: {e}")

if __name__ == "__main__":
    exe_name = "main.exe" if getattr(sys, 'frozen', False) else "main.py"
    add_to_startup(exe_name)
