import pvporcupine
import sounddevice as sd
import struct

def wait_for_wake_word(keyword="jarvis"):
    porcupine = pvporcupine.create(keywords=[keyword])
    samplerate = porcupine.sample_rate
    frame_length = porcupine.frame_length

    print("🎧 Listening for wake word...")

    with sd.RawInputStream(samplerate=samplerate, blocksize=frame_length, dtype='int16',
                           channels=1) as stream:
        while True:
            pcm = stream.read(frame_length)[0]
            pcm = struct.unpack_from("h" * frame_length, pcm)
            result = porcupine.process(pcm)
            if result >= 0:
                print("✅ Wake word detected!")
                return
