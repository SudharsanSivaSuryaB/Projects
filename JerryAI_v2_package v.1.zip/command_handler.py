import subprocess
import os
import platform
import pyautogui
from email_manager import read_emails_summary

def open_app(name):
    system = platform.system()
    try:
        if system == 'Windows':
            subprocess.Popen([name])
        elif system == 'Darwin':
            subprocess.Popen(['open', '-a', name])
        else:
            subprocess.Popen([name])
        print(f"Opened app: {name}")
    except Exception as e:
        print(f"Failed to open {name}: {e}")

def close_app(process_name):
    system = platform.system()
    try:
        if system == 'Windows':
            os.system(f"taskkill /im {process_name} /f")
        else:
            os.system(f"pkill -f {process_name}")
        print(f"Closed app: {process_name}")
    except Exception as e:
        print(f"Failed to close {process_name}: {e}")

def type_text(text):
    print(f"Typing: {text}")
    pyautogui.write(text, interval=0.02)

def handle_command(command: str):
    if command.startswith('open '):
        app = command.replace('open ', '', 1).strip()
        open_app(app)
    elif command.startswith('close '):
        app = command.replace('close ', '', 1).strip()
        close_app(app)
    elif command.startswith('type '):
        text = command.replace('type ', '', 1)
        type_text(text)
    elif 'email' in command or 'emails' in command or 'meeting' in command:
        read_emails_summary()
    else:
        print(f"Unknown or unsupported command: {command}")
