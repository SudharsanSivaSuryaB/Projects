import queue
import json
import sounddevice as sd
import vosk
import os

VOSK_MODEL_PATH = "models/vosk-model-small-en-us-0.15"

if not os.path.exists(VOSK_MODEL_PATH):
    raise RuntimeError(
        f"Vosk model not found at {VOSK_MODEL_PATH}. Please download a Vosk model and place it there."
    )

model = vosk.Model(VOSK_MODEL_PATH)
q = queue.Queue()

def _audio_callback(indata, frames, time, status):
    q.put(bytes(indata))

def recognize_from_queue(timeout=None):
    rec = vosk.KaldiRecognizer(model, 16000)
    with sd.RawInputStream(samplerate=16000, blocksize=8000, dtype="int16",
                           channels=1, callback=_audio_callback):
        while True:
            data = q.get()
            if rec.AcceptWaveform(data):
                res = json.loads(rec.Result())
                return res.get("text", "")
